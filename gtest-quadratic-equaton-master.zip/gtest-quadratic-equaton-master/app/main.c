#include <stdio.h>

#include "qequation.h"

int main()
{
    printf("Hello World!\n");
}
